# Flexible Packaging — Safe Upgrade

এই version-এ পুরোনো project structure ও local saved/profile data রাখার চেষ্টা করা হয়েছে। Firebase authentication যোগ করা হয়েছে, কিন্তু পুরোনো local data মুছে দেওয়া হয়নি।

## Added
- Firebase Core
- Firebase Authentication (email/password)
- Email verification
- Forgot password
- Firestore user profile
- Firebase Storage upload service foundation
- Firebase Cloud Messaging token registration foundation
- Secure Firestore/Storage rules using admin custom claim
- Google Services Gradle plugin in GitHub Actions
- Firebase-ready APK build workflow

## Important
- পুরোনো SharedPreferences data delete করা হয়নি।
- পুরোনো local login state আর Firebase login হিসেবে গ্রহণ করা হয় না; এতে fake authentication এড়ানো হয়েছে।
- Admin access client-side button দিয়ে দেওয়া হয়নি; `admin` custom claim প্রয়োজন।
- Phone OTP, full Firestore job sync, application upload flow, and production notification composer এখনও Firebase Console/backend configuration এবং end-to-end device testing চায়।
