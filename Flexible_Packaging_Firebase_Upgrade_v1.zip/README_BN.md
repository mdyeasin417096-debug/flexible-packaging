# Flexible Packaging — Android Job Portal

এটি Flutter দিয়ে তৈরি একটি কাজ করা (installable) starter application। এতে আপনার দেখানো UI-এর ভিত্তিতে Login, Registration, Dashboard, Jobs, Search, Saved Jobs, Applications, Notifications, Profile, Calculator, Film Library, Technical Guides, Safety এবং Admin Panel রাখা হয়েছে।

## গুরুত্বপূর্ণ
এটি এখন **local/demo mode**-এ চলে। ফলে অ্যাপটি build করে ফোনে ইনস্টল করা যাবে এবং মূল flow পরীক্ষা করা যাবে। কিন্তু আসল online Job Portal করতে Firebase/Backend যুক্ত করতে হবে—কারণ user, job, application, CV, notification ও admin data বহু ডিভাইসে sync করার জন্য server database দরকার।

## Build
1. Flutter SDK ও Android Studio install করুন।
2. এই project folder Android Studio/VS Code-এ খুলুন।
3. Terminal-এ চালান:
   - `flutter pub get`
   - `flutter run`
4. APK বানাতে: `flutter build apk --release`
5. Play Store-এর জন্য: `flutter build appbundle --release`

## Demo Admin
Login screen-এ **Demo Admin Panel** চাপলে Admin Panel খুলবে।

## Production Firebase সংযোগ
Firebase project তৈরি করে FlutterFire CLI দিয়ে `flutterfire configure` চালান। তারপর Authentication, Firestore, Storage এবং Cloud Messaging যুক্ত করে local `AppStore`-এর জায়গায় repository/service layer ব্যবহার করুন।

## Design
App name: Flexible Packaging
কোনো `v1.0` লেখা UI-তে ব্যবহার করা হয়নি।
