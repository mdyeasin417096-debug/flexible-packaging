import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  final store = await AppStore.create();
  runApp(FlexiblePackagingApp(store: store));
}

class AppStore extends ChangeNotifier {
  late SharedPreferences prefs;
  final FirebaseService firebase = FirebaseService.instance;
  StreamSubscription<User?>? _authSub;
  String language = 'বাংলা';
  String? userName;
  String? userEmail;
  String? userPhone;
  bool loggedIn = false;
  bool isAdmin = false;
  List<Job> jobs = demoJobs;
  final Set<String> saved = {};
  final List<ApplicationItem> applications = [];
  final List<NewsItem> news = demoNews;

  static Future<AppStore> create() async {
    final s = AppStore();
    s.prefs = await SharedPreferences.getInstance();
    s.language = s.prefs.getString('language') ?? 'বাংলা';
    s.userName = s.prefs.getString('name');
    s.userEmail = s.prefs.getString('email');
    s.userPhone = s.prefs.getString('phone');
    s.saved.addAll(s.prefs.getStringList('saved') ?? []);
    final u = s.firebase.auth.currentUser;
    if (u != null) {
      s.loggedIn = true;
      s.userEmail = u.email;
      await s._loadFirebaseProfile(u);
    } else {
      // Preserve the old local profile/saved data, but never treat it as Firebase authentication.
      s.loggedIn = false;
    }
    s._authSub = s.firebase.auth.authStateChanges().listen((u) async {
      if (u == null) {
        s.loggedIn = false;
        s.isAdmin = false;
      } else {
        s.loggedIn = true;
        s.userEmail = u.email;
        await s._loadFirebaseProfile(u);
      }
      await s.persist();
    });
    return s;
  }

  Future<void> _loadFirebaseProfile(User u) async {
    final doc = await firebase.getUserProfile(u.uid);
    final data = doc.data();
    if (data != null) {
      userName = (data['name'] ?? userName)?.toString();
      userPhone = (data['phone'] ?? userPhone)?.toString();
    }
    final token = await u.getIdTokenResult(true);
    isAdmin = token.claims?['admin'] == true;
    await firebase.registerMessagingToken(u.uid);
  }

  Future<void> registerAccount({required String name, required String email, required String password, String phone = ''}) async {
    final cred = await firebase.register(email, password);
    userName = name; userEmail = email; userPhone = phone; loggedIn = true; isAdmin = false;
    await firebase.saveUserProfile(cred.user!.uid, {'name': name, 'email': email, 'phone': phone, 'role': 'user', 'createdAt': FieldValue.serverTimestamp()});
    await firebase.sendEmailVerification();
    await persist();
  }

  Future<void> loginWithPassword(String email, String password) async {
    final cred = await firebase.login(email, password);
    userEmail = cred.user!.email; loggedIn = true;
    await _loadFirebaseProfile(cred.user!);
    await persist();
  }

  Future<void> resetPassword(String email) => firebase.sendPasswordReset(email);

  Future<void> resendVerification() => firebase.sendEmailVerification();

  bool get bn => language == 'বাংলা';
  Future<void> persist() async {
    await prefs.setString('language', language);
    await prefs.setBool('loggedIn', loggedIn);
    await prefs.setBool('admin', isAdmin);
    if (userName != null) await prefs.setString('name', userName!);
    if (userEmail != null) await prefs.setString('email', userEmail!);
    if (userPhone != null) await prefs.setString('phone', userPhone!);
    await prefs.setStringList('saved', saved.toList());
    notifyListeners();
  }

  Future<void> setLanguage(String v) async { language = v; await persist(); }
  Future<void> login(String name, String email, {bool admin = false}) async {
    // Backward-compatible local profile update. Production authentication uses loginWithPassword().
    userName = name; userEmail = email; loggedIn = true; isAdmin = false; await persist();
  }
  Future<void> logout() async { await firebase.logout(); loggedIn = false; isAdmin = false; await persist(); }
  Future<void> toggleSaved(String id) async {
    saved.contains(id) ? saved.remove(id) : saved.add(id); await persist();
  }
  void addApplication(String jobId) {
    if (!applications.any((a) => a.jobId == jobId)) applications.add(ApplicationItem(jobId: jobId, date: DateTime.now(), status: 'Under Review'));
    notifyListeners();
  }
  void addJob(Job job) { jobs.insert(0, job); notifyListeners(); }
  void removeJob(String id) { jobs.removeWhere((j) => j.id == id); notifyListeners(); }
}

class Job {
  final String id, title, company, location, salary, type, description;
  final DateTime posted, deadline;
  Job({required this.id, required this.title, required this.company, required this.location, required this.salary, required this.type, required this.description, required this.posted, required this.deadline});
  int get remainingDays => max(0, deadline.difference(DateTime.now()).inDays);
}
class ApplicationItem { final String jobId, status; final DateTime date; ApplicationItem({required this.jobId, required this.date, required this.status}); }
class NewsItem { final String title, text; NewsItem(this.title, this.text); }

final demoJobs = <Job>[
  Job(id:'1', title:'Production Operator', company:'Global Packaging Ltd.', location:'Dhaka, Bangladesh', salary:'25,000 - 35,000', type:'Full Time', description:'Operate and monitor production machines. Maintain product quality and safety standards. Follow company policies and procedures.', posted:DateTime.now().subtract(const Duration(hours:2)), deadline:DateTime.now().add(const Duration(days:14))),
  Job(id:'2', title:'Warehouse Assistant', company:'Fresh Foods Ltd.', location:'Chattogram, Bangladesh', salary:'18,000 - 25,000', type:'Full Time', description:'Support warehouse receiving, storage and dispatch operations.', posted:DateTime.now().subtract(const Duration(hours:4)), deadline:DateTime.now().add(const Duration(days:9))),
  Job(id:'3', title:'Sales Executive', company:'ABC Trading Co.', location:'Sylhet, Bangladesh', salary:'20,000 - 30,000', type:'Full Time', description:'Manage customers, sales targets and daily reports.', posted:DateTime.now().subtract(const Duration(hours:5)), deadline:DateTime.now().add(const Duration(days:6))),
  Job(id:'4', title:'Quality Control Inspector', company:'Packaging Pack Ltd.', location:'Narayanganj, Bangladesh', salary:'22,000 - 30,000', type:'Full Time', description:'Inspect printed film, lamination and pouch quality against specifications.', posted:DateTime.now().subtract(const Duration(days:1)), deadline:DateTime.now().add(const Duration(days:3))),
];
final demoNews = <NewsItem>[NewsItem('Breaking News', 'নতুন চাকরির বিজ্ঞপ্তি প্রকাশ হয়েছে। আজই আবেদন করুন।'), NewsItem('New Job Alert', 'Flexible Packaging sector-এ নতুন Production Operator পদ যুক্ত হয়েছে।')];

class FlexiblePackagingApp extends StatelessWidget {
  final AppStore store;
  const FlexiblePackagingApp({super.key, required this.store});
  @override Widget build(BuildContext context) => AnimatedBuilder(animation: store, builder: (_, __) => MaterialApp(debugShowCheckedModeBanner:false, title:'Flexible Packaging', theme: ThemeData(useMaterial3:true, fontFamily:'Roboto', colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff0B5CAB)), scaffoldBackgroundColor: const Color(0xffF7FAFC)), home: store.loggedIn ? (store.isAdmin ? AdminPage(store:store) : HomePage(store:store)) : SplashPage(store:store)));
}

class Logo extends StatelessWidget { final double size; const Logo({super.key,this.size=48}); @override Widget build(BuildContext context)=>Row(mainAxisSize:MainAxisSize.min,children:[Container(width:size,height:size,decoration:BoxDecoration(borderRadius:BorderRadius.circular(size*.22),gradient:const LinearGradient(colors:[Color(0xff0B5CAB),Color(0xff18B49A)])),child:Center(child:Text('FP',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:size*.32)))),const SizedBox(width:8),const Flexible(child:Text('Flexible\nPackaging',style:TextStyle(fontWeight:FontWeight.w800,color:Color(0xff073B75),height:.95)))]); }

class SplashPage extends StatefulWidget { final AppStore store; const SplashPage({super.key,required this.store}); @override State<SplashPage> createState()=>_SplashPageState(); }
class _SplashPageState extends State<SplashPage>{ @override void initState(){super.initState(); Future.delayed(const Duration(milliseconds:1200),(){if(mounted) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>LanguagePage(store:widget.store)));});} @override Widget build(BuildContext c)=>Scaffold(body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Logo(size:76),const SizedBox(height:30),Text(widget.store.bn?'আপনার পরবর্তী সুযোগ খুঁজুন':'Find Your Next Opportunity',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w700,color:Color(0xff073B75))),const SizedBox(height:8),Text(widget.store.bn?'Better Jobs • Better Future':'Better Jobs • Better Future',style:const TextStyle(color:Colors.black54))]))); }

class LanguagePage extends StatelessWidget { final AppStore store; const LanguagePage({super.key,required this.store}); @override Widget build(BuildContext c)=>Scaffold(body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Logo(size:55),const SizedBox(height:30),const Text('Select Language',style:TextStyle(color:Colors.black54)),const SizedBox(height:20),_lang(c,'বাংলা'),const SizedBox(height:12),_lang(c,'English',outline:true)])));} Widget _lang(BuildContext c,String v,{bool outline=false})=>SizedBox(width:double.infinity,height:54,child:ElevatedButton(style:ElevatedButton.styleFrom(backgroundColor:outline?Colors.white:const Color(0xff0B75D1),foregroundColor:outline?const Color(0xff073B75):Colors.white,side:outline?const BorderSide(color:Color(0xff0B75D1)):null),onPressed:() async{await store.setLanguage(v);if(c.mounted)Navigator.pushReplacement(c,MaterialPageRoute(builder:(_)=>LoginPage(store:store)));},child:Text(v,style:const TextStyle(fontWeight:FontWeight.w800))));}

class LoginPage extends StatefulWidget { final AppStore store; const LoginPage({super.key,required this.store}); @override State<LoginPage> createState()=>_LoginState(); }
class _LoginState extends State<LoginPage>{ final email=TextEditingController(); final pass=TextEditingController(); bool busy=false;
 Future<void> _login() async { final e=email.text.trim(), p=pass.text; if(e.isEmpty||p.isEmpty){_msg('Email ও Password দিন');return;} setState(()=>busy=true); try { await widget.store.loginWithPassword(e,p); if(mounted) _msg(widget.store.firebase.auth.currentUser?.emailVerified==true?'Login successful':'Login successful — email verification pending'); } on FirebaseAuthException catch(x){_msg(x.message??x.code);} catch(x){_msg('Login failed: $x');} finally {if(mounted)setState(()=>busy=false);} }
 Future<void> _reset() async { final e=email.text.trim(); if(e.isEmpty){_msg('আগে Email দিন');return;} try{await widget.store.resetPassword(e);_msg('Password reset email sent');}on FirebaseAuthException catch(x){_msg(x.message??x.code);} }
 void _msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));
 @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[const Logo(size:48),const SizedBox(height:30),const Align(alignment:Alignment.centerLeft,child:Text('Welcome Back!',style:TextStyle(fontSize:25,fontWeight:FontWeight.w800,color:Color(0xff073B75)))),const Align(alignment:Alignment.centerLeft,child:Text('Login to your account',style:TextStyle(color:Colors.black54))),const SizedBox(height:22),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',prefixIcon:Icon(Icons.email_outlined),border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock_outline),border:OutlineInputBorder())),Align(alignment:Alignment.centerRight,child:TextButton(onPressed:_reset,child:const Text('Forgot Password?'))),const SizedBox(height:8),SizedBox(width:double.infinity,height:52,child:ElevatedButton(onPressed:busy?null:_login,child:busy?const SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2)):const Text('Login'))),TextButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>RegistrationPage(store:widget.store))),child:const Text('Don\'t have an account?  Register'))]))));}}

class RegistrationPage extends StatefulWidget{final AppStore store;const RegistrationPage({super.key,required this.store});@override State<RegistrationPage>createState()=>_RegState();}
class _RegState extends State<RegistrationPage>{final name=TextEditingController(),email=TextEditingController(),pass=TextEditingController(),confirm=TextEditingController(),phone=TextEditingController();bool busy=false;
 Future<void> _register() async {if(name.text.trim().isEmpty||email.text.trim().isEmpty||pass.text.length<6||pass.text!=confirm.text){_msg('নাম, সঠিক Email এবং একই Password (কমপক্ষে 6 অক্ষর) দিন');return;}setState(()=>busy=true);try{await widget.store.registerAccount(name:name.text.trim(),email:email.text.trim(),password:pass.text,phone:phone.text.trim());if(mounted){_msg('Account created. Verification email পাঠানো হয়েছে।');Navigator.pop(context);}}on FirebaseAuthException catch(x){_msg(x.message??x.code);}catch(x){_msg('Registration failed: $x');}finally{if(mounted)setState(()=>busy=false);}}
 void _msg(String x)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create Your Account')),body:ListView(padding:const EdgeInsets.all(24),children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Full Name',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'Phone (optional)',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:confirm,obscureText:true,decoration:const InputDecoration(labelText:'Confirm Password',border:OutlineInputBorder())),const SizedBox(height:20),SizedBox(height:52,child:ElevatedButton(onPressed:busy?null:_register,child:busy?const SizedBox(width:22,height:22,child:CircularProgressIndicator(strokeWidth:2)):const Text('Register')))]));}

class HomePage extends StatefulWidget{final AppStore store;const HomePage({super.key,required this.store});@override State<HomePage>createState()=>_HomeState();}
class _HomeState extends State<HomePage>{int index=0;@override Widget build(BuildContext c){final pages=[Dashboard(store:widget.store),SearchPage(store:widget.store),SavedPage(store:widget.store),ApplicationsPage(store:widget.store),ProfilePage(store:widget.store)];return Scaffold(body:pages[index],bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const[NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.search),label:'Search'),NavigationDestination(icon:Icon(Icons.favorite_border),selectedIcon:Icon(Icons.favorite),label:'Saved'),NavigationDestination(icon:Icon(Icons.assignment_outlined),label:'Applications'),NavigationDestination(icon:Icon(Icons.person_outline),label:'Profile')]));}}

class Dashboard extends StatelessWidget{final AppStore store;const Dashboard({super.key,required this.store});@override Widget build(BuildContext c)=>SafeArea(child:CustomScrollView(slivers:[SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,18,16,8),child:Row(children:[const Logo(size:42),const Spacer(),IconButton(onPressed:(){Navigator.push(c,MaterialPageRoute(builder:(_)=>NotificationsPage(store:store)));},icon:const Icon(Icons.notifications_none))]))),SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.all(16),child:Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(24),gradient:const LinearGradient(colors:[Color(0xff0B5CAB),Color(0xff18B49A)])),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Flexible Printing Packaging',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900)),SizedBox(height:8),Text('Printing • Lamination • Slitting • Pouch • Quality',style:TextStyle(color:Colors.white70)),SizedBox(height:16),Icon(Icons.local_shipping_outlined,size:70,color:Colors.white)]))),SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Row(children:[const Icon(Icons.campaign,color:Colors.orange),const SizedBox(width:10),Expanded(child:Text(store.news.first.text,style:const TextStyle(fontWeight:FontWeight.w700)))]))))),SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Expanded(child:_action(c,Icons.work,'Jobs',()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>JobsPage(store:store))))),const SizedBox(width:12),Expanded(child:_action(c,Icons.add_task,'New Job Apply',()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>JobsPage(store:store)))))]))),SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,0,16,8),child:Row(children:[const Text('Latest Job Openings',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const Spacer(),Text('${store.jobs.length} jobs',style:const TextStyle(color:Colors.black54))]))),SliverList.builder(itemCount:store.jobs.length,itemBuilder:(_,i)=>Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:5),child:JobCard(job:store.jobs[i],store:store)))]);}
Widget _action(BuildContext c,IconData icon,String t,VoidCallback f)=>InkWell(onTap:f,borderRadius:BorderRadius.circular(18),child:Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(18),boxShadow:[BoxShadow(color:Colors.black.withOpacity(.06),blurRadius:10)]),child:Row(children:[Icon(icon,color:const Color(0xff0B5CAB)),const SizedBox(width:10),Expanded(child:Text(t,style:const TextStyle(fontWeight:FontWeight.w800)))])));
}

class JobCard extends StatelessWidget{final Job job;final AppStore store;const JobCard({super.key,required this.job,required this.store});@override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Container(width:44,height:44,decoration:BoxDecoration(color:const Color(0xffE9F3FF),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.business,color:Color(0xff0B5CAB))),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(job.title,style:const TextStyle(fontWeight:FontWeight.w900)),Text(job.company,style:const TextStyle(color:Colors.black54))])),IconButton(onPressed:()=>store.toggleSaved(job.id),icon:Icon(store.saved.contains(job.id)?Icons.favorite:Icons.favorite_border,color:store.saved.contains(job.id)?Colors.red:null))]),const SizedBox(height:8),Text('📍 ${job.location}'),Text('৳ ${job.salary}',style:const TextStyle(color:Color(0xff168D67),fontWeight:FontWeight.w800)),Text('${job.type} • ${job.remainingDays} days left',style:const TextStyle(color:Colors.black54)),const SizedBox(height:10),Row(children:[Expanded(child:OutlinedButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>JobDetailsPage(job:job,store:store))),child:const Text('View'))),const SizedBox(width:8),Expanded(child:ElevatedButton(onPressed:()=>store.addApplication(job.id),child:const Text('Apply Now')))])])));}

class JobsPage extends StatelessWidget{final AppStore store;const JobsPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('All Jobs')),body:ListView(padding:const EdgeInsets.all(12),children:store.jobs.map((j)=>JobCard(job:j,store:store)).toList());}
class SearchPage extends StatefulWidget{final AppStore store;const SearchPage({super.key,required this.store});@override State<SearchPage>createState()=>_SearchState();}
class _SearchState extends State<SearchPage>{String q='';@override Widget build(BuildContext c){final list=widget.store.jobs.where((j)=>('${j.title} ${j.company} ${j.location}').toLowerCase().contains(q.toLowerCase())).toList();return SafeArea(child:Column(children:[Padding(padding:const EdgeInsets.all(16),child:TextField(onChanged:(v)=>setState(()=>q=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Job title, company or keyword',border:OutlineInputBorder()))),Expanded(child:ListView(padding:const EdgeInsets.symmetric(horizontal:12),children:list.map((j)=>JobCard(job:j,store:widget.store)).toList()))]));}}
class SavedPage extends StatelessWidget{final AppStore store;const SavedPage({super.key,required this.store});@override Widget build(BuildContext c){final list=store.jobs.where((j)=>store.saved.contains(j.id)).toList();return SafeArea(child:Column(children:[const Padding(padding:EdgeInsets.all(18),child:Align(alignment:Alignment.centerLeft,child:Text('Saved Jobs',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)))),Expanded(child:list.isEmpty?const Center(child:Text('No saved jobs yet')):ListView(padding:const EdgeInsets.all(12),children:list.map((j)=>JobCard(job:j,store:store)).toList()))]));}}
class ApplicationsPage extends StatelessWidget{final AppStore store;const ApplicationsPage({super.key,required this.store});@override Widget build(BuildContext c)=>SafeArea(child:Column(children:[const Padding(padding:EdgeInsets.all(18),child:Align(alignment:Alignment.centerLeft,child:Text('My Applications',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)))),Expanded(child:store.applications.isEmpty?const Center(child:Text('No applications yet')):ListView(padding:const EdgeInsets.all(12),children:store.applications.map((a){final j=store.jobs.firstWhere((x)=>x.id==a.jobId);final days=DateTime.now().difference(a.date).inDays;return Card(child:ListTile(leading:const Icon(Icons.assignment),title:Text(j.title),subtitle:Text('${j.company}\nApplied ${days} days ago'),isThreeLine:true,trailing:Chip(label:Text(a.status)));}).toList()))]));}

class JobDetailsPage extends StatelessWidget{final Job job;final AppStore store;const JobDetailsPage({super.key,required this.job,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Job Details')),body:ListView(padding:const EdgeInsets.all(18),children:[Text(job.title,style:const TextStyle(fontSize:27,fontWeight:FontWeight.w900,color:Color(0xff073B75))),Text(job.company,style:const TextStyle(fontSize:17)),const SizedBox(height:12),Text('📍 ${job.location}'),Text('৳ ${job.salary}'),Text('${job.type} • Posted ${DateFormat('dd MMM yyyy').format(job.posted)}'),Text('Application deadline: ${DateFormat('dd MMM yyyy').format(job.deadline)} (${job.remainingDays} days left)'),const Divider(height:30),const Text('Job Description',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(job.description),const SizedBox(height:24),Row(children:[Expanded(child:OutlinedButton(onPressed:()=>store.toggleSaved(job.id),child:const Text('Save'))),const SizedBox(width:10),Expanded(child:ElevatedButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>ApplyPage(job:job,store:store))),child:const Text('Apply Now')))])]));}
class ApplyPage extends StatefulWidget{final Job job;final AppStore store;const ApplyPage({super.key,required this.job,required this.store});@override State<ApplyPage>createState()=>_ApplyState();}
class _ApplyState extends State<ApplyPage>{String? file;final msg=TextEditingController();@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Apply for Job')),body:ListView(padding:const EdgeInsets.all(18),children:[Text(widget.job.title,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),Text(widget.job.company),const SizedBox(height:24),OutlinedButton.icon(onPressed:()async{final x=await ImagePicker().pickImage(source:ImageSource.gallery);if(x!=null)setState(()=>file=x.name);},icon:const Icon(Icons.upload_file),label:Text(file==null?'Upload Your CV / Resume':file!)),const SizedBox(height:12),TextField(controller:msg,maxLines:5,decoration:const InputDecoration(labelText:'Additional Information (Optional)',border:OutlineInputBorder())),const SizedBox(height:22),SizedBox(height:52,child:ElevatedButton(onPressed:(){widget.store.addApplication(widget.job.id);ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Application submitted successfully')));Navigator.pop(c);},child:const Text('Submit Application')))]));}

class NotificationsPage extends StatelessWidget{final AppStore store;const NotificationsPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Notifications')),body:ListView(padding:const EdgeInsets.all(12),children:const[Card(child:ListTile(leading:Icon(Icons.info,color:Colors.blue),title:Text('Your application status updated'),subtitle:Text('Production Operator • 2 hours ago'))),Card(child:ListTile(leading:Icon(Icons.work,color:Colors.orange),title:Text('New job match for you'),subtitle:Text('New Production Operator job'))),Card(child:ListTile(leading:Icon(Icons.notifications_active,color:Colors.green),title:Text('Job alert'),subtitle:Text('New jobs are available')))]);}

class ProfilePage extends StatelessWidget{final AppStore store;const ProfilePage({super.key,required this.store});@override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[Center(child:const CircleAvatar(radius:42,child:Icon(Icons.person,size:48))),const SizedBox(height:10),Center(child:Text(store.userName??'User',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))),Center(child:Text(store.userEmail??'')),const SizedBox(height:18),..._items(c)]));List<Widget>_items(BuildContext c)=>[ListTile(leading:const Icon(Icons.person),title:const Text('My Profile'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>EditProfilePage(store:store)))),ListTile(leading:const Icon(Icons.description),title:const Text('My CV / Resume'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>CVPage(store:store)))),ListTile(leading:const Icon(Icons.calculate),title:const Text('Packaging Calculator'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>CalculatorPage(store:store)))),ListTile(leading:const Icon(Icons.layers),title:const Text('Flexible Packaging Films'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>FilmPage(store:store)))),ListTile(leading:const Icon(Icons.menu_book),title:const Text('Technical Guides'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>GuidesPage(store:store)))),ListTile(leading:const Icon(Icons.security),title:const Text('Safety'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>SafetyPage(store:store)))),ListTile(leading:const Icon(Icons.settings),title:const Text('Settings'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>SettingsPage(store:store)))),ListTile(leading:const Icon(Icons.logout,color:Colors.red),title:const Text('Logout'),onTap:store.logout)];}

class EditProfilePage extends StatefulWidget{final AppStore store;const EditProfilePage({super.key,required this.store});@override State<EditProfilePage>createState()=>_EditProfileState();}
class _EditProfileState extends State<EditProfilePage>{late TextEditingController n,e;@override void initState(){super.initState();n=TextEditingController(text:widget.store.userName);e=TextEditingController(text:widget.store.userEmail);}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('My Profile')),body:ListView(padding:const EdgeInsets.all(18),children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Full Name',border:OutlineInputBorder())),const SizedBox(height:12),TextField(controller:e,decoration:const InputDecoration(labelText:'Email',border:OutlineInputBorder())),const SizedBox(height:18),ElevatedButton(onPressed:()async{widget.store.userName=n.text;widget.store.userEmail=e.text;await widget.store.persist();if(c.mounted)Navigator.pop(c);},child:const Text('Save'))]));}
class CVPage extends StatelessWidget{final AppStore store;const CVPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('My CV / Resume')),body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.picture_as_pdf,size:70,color:Colors.red),const SizedBox(height:12),const Text('Upload and manage your CV/Resume'),const SizedBox(height:18),ElevatedButton.icon(onPressed:()async{final x=await ImagePicker().pickImage(source:ImageSource.gallery);if(x!=null&&c.mounted)ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('Selected: ${x.name}')));},icon:const Icon(Icons.upload_file),label:const Text('Select CV'))]));}

class CalculatorPage extends StatefulWidget{final AppStore store;const CalculatorPage({super.key,required this.store});@override State<CalculatorPage>createState()=>_CalcState();}
class _CalcState extends State<CalculatorPage>{final weight=TextEditingController(),width=TextEditingController(),gsm=TextEditingController(),length=TextEditingController();String result='';void calcLength(){final w=double.tryParse(weight.text),wi=double.tryParse(width.text),g=double.tryParse(gsm.text);if(w!=null&&wi!=null&&g!=null)setState(()=>result='Length = ${(w*1000/(wi*g)).toStringAsFixed(2)} meter');}void calcWeight(){final l=double.tryParse(length.text),wi=double.tryParse(width.text),g=double.tryParse(gsm.text);if(l!=null&&wi!=null&&g!=null)setState(()=>result='Weight = ${(l*wi*g/1000).toStringAsFixed(3)} kg');}@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Packaging Calculator')),body:ListView(padding:const EdgeInsets.all(18),children:[const Text('KG → Meter (GSM method)',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),TextField(controller:weight,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Weight (kg)',border:OutlineInputBorder())),const SizedBox(height:8),TextField(controller:width,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Width (m)',border:OutlineInputBorder())),const SizedBox(height:8),TextField(controller:gsm,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'GSM (g/m²)',border:OutlineInputBorder())),const SizedBox(height:8),ElevatedButton(onPressed:calcLength,child:const Text('Calculate Meter')),const Divider(height:35),const Text('Meter → KG',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),TextField(controller:length,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Length (m)',border:OutlineInputBorder())),const SizedBox(height:8),ElevatedButton(onPressed:calcWeight,child:const Text('Calculate KG')),const SizedBox(height:20),Card(child:Padding(padding:const EdgeInsets.all(20),child:Text(result.isEmpty?'Result will appear here':result,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))))]));}
class FilmPage extends StatelessWidget{final AppStore store;const FilmPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Flexible Packaging Films')),body:ListView(padding:const EdgeInsets.all(12),children:['BOPP','PET','PE','LDPE','LLDPE','HDPE','CPP','MCPP','MPET','Nylon / PA','EVOH','Aluminium Foil','Paper','Metallized Film','Barrier Film'].map((x)=>Card(child:ListTile(leading:const Icon(Icons.layers),title:Text(x),subtitle:const Text('Material information, typical use and selection notes')))).toList());}
class GuidesPage extends StatelessWidget{final AppStore store;const GuidesPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Technical Guides')),body:ListView(padding:const EdgeInsets.all(12),children:['Printing','Lamination','Slitting','Sealing','Multilayer Pouch','Quality Control','Problems & Solutions'].map((x)=>ExpansionTile(title:Text(x,style:const TextStyle(fontWeight:FontWeight.w800)),children:[const Padding(padding:EdgeInsets.all(16),child:Text('Common problems, possible causes, quality checks and safe corrective actions. Follow your plant SOP and manufacturer guidance.'))])).toList());}
class SafetyPage extends StatelessWidget{final AppStore store;const SafetyPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Safety')),body:ListView(padding:const EdgeInsets.all(18),children:const[Text('Safety First',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),SizedBox(height:12),Text('Machine safety • PPE • Printing/ink safety • Solvent awareness • Lamination • Slitting • Pouch machine • Electrical • Fire • Emergency • First aid.\n\nAlways follow workplace SOPs, SDS and trained-supervisor instructions. This app does not replace formal safety training.')]);}
class SettingsPage extends StatelessWidget{final AppStore store;const SettingsPage({super.key,required this.store});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Settings')),body:ListView(children:[ListTile(title:const Text('Language / ভাষা'),trailing:DropdownButton<String>(value:store.language,items:const[DropdownMenuItem(value:'বাংলা',child:Text('বাংলা')),DropdownMenuItem(value:'English',child:Text('English'))],onChanged:(v){if(v!=null)store.setLanguage(v);})),const ListTile(title:Text('Job Alerts'),trailing:Switch(value:true,onChanged:null)),const ListTile(title:Text('Push Notifications'),trailing:Switch(value:true,onChanged:null))]));}

class AdminPage extends StatefulWidget{final AppStore store;const AdminPage({super.key,required this.store});@override State<AdminPage>createState()=>_AdminState();}
class _AdminState extends State<AdminPage>{int tab=0;@override Widget build(BuildContext c){return Scaffold(appBar:AppBar(title:const Text('Flexible Packaging • Admin Panel'),actions:[IconButton(onPressed:()=>widget.store.logout(),icon:const Icon(Icons.logout))]),drawer:Drawer(child:ListView(children:[const DrawerHeader(child:Logo(size:42)),...['Dashboard','Jobs','Applications','Users','News','Analytics','Technical Content'].asMap().entries.map((e)=>ListTile(selected:tab==e.key,title:Text(e.value),onTap:(){setState(()=>tab=e.key);Navigator.pop(c);})),const Divider(),ListTile(title:const Text('Logout'),onTap:widget.store.logout)])),body:_body());}Widget _body(){switch(tab){case 1:return AdminJobs(store:widget.store);case 2:return AdminApplications(store:widget.store);case 3:return const AdminUsers();case 4:return AdminNews(store:widget.store);case 5:return AdminAnalytics(store:widget.store);case 6:return const AdminTechnical();default:return AdminDashboard(store:widget.store);}}}
class AdminDashboard extends StatelessWidget{final AppStore store;const AdminDashboard({super.key,required this.store});@override Widget build(BuildContext c)=>GridView.count(padding:const EdgeInsets.all(18),crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,children:[_card('Users','1,248',Icons.people),_card('Online','86',Icons.circle),_card('New Jobs','${store.jobs.length}',Icons.work),_card('Applications','${store.applications.length}',Icons.assignment),_card('Expiring Soon','${store.jobs.where((j)=>j.remainingDays<=3).length}',Icons.timer),_card('Active Jobs','${store.jobs.length}',Icons.check_circle)]);}Widget _card(String a,String b,IconData i)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i,color:const Color(0xff0B5CAB)),const Spacer(),Text(b,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900)),Text(a,style:const TextStyle(color:Colors.black54))])));}
class AdminJobs extends StatelessWidget{final AppStore store;const AdminJobs({super.key,required this.store});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[ElevatedButton.icon(onPressed:(){showDialog(context:c,builder:(_)=>NewJobDialog(store:store));},icon:const Icon(Icons.add),label:const Text('Add New Job')),...store.jobs.map((j)=>Card(child:ListTile(title:Text(j.title),subtitle:Text('${j.company} • ${j.remainingDays} days left'),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>store.removeJob(j.id)))))]);}
class NewJobDialog extends StatefulWidget{final AppStore store;const NewJobDialog({super.key,required this.store});@override State<NewJobDialog>createState()=>_NewJobState();}
class _NewJobState extends State<NewJobDialog>{final t=TextEditingController(),co=TextEditingController(),loc=TextEditingController(),sal=TextEditingController();@override Widget build(BuildContext c)=>AlertDialog(title:const Text('Add New Job'),content:SingleChildScrollView(child:Column(children:[TextField(controller:t,decoration:const InputDecoration(labelText:'Job Title')),TextField(controller:co,decoration:const InputDecoration(labelText:'Company')),TextField(controller:loc,decoration:const InputDecoration(labelText:'Location')),TextField(controller:sal,decoration:const InputDecoration(labelText:'Salary'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Cancel')),ElevatedButton(onPressed:(){widget.store.addJob(Job(id:Random().nextInt(999999).toString(),title:t.text,company:co.text,location:loc.text,salary:sal.text,type:'Full Time',description:'Added by Admin',posted:DateTime.now(),deadline:DateTime.now().add(const Duration(days:30))));Navigator.pop(c);},child:const Text('Publish'))]);}
class AdminApplications extends StatelessWidget{final AppStore store;const AdminApplications({super.key,required this.store});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:store.applications.map((a){final j=store.jobs.firstWhere((x)=>x.id==a.jobId);return Card(child:ListTile(title:Text(j.title),subtitle:Text('Applied ${DateFormat('dd MMM yyyy').format(a.date)} • ${DateTime.now().difference(a.date).inDays} days ago'),trailing:Text(a.status)));}).toList());}
class AdminUsers extends StatelessWidget{const AdminUsers({super.key});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(18),children:const[Card(child:ListTile(title:Text('Total Users'),trailing:Text('1,248'))),Card(child:ListTile(title:Text('Online Now'),trailing:Text('86'))),Card(child:ListTile(title:Text('New Users Today'),trailing:Text('24'))),Card(child:ListTile(title:Text('Active Users'),trailing:Text('1,102')))]);}
class AdminNews extends StatelessWidget{final AppStore store;const AdminNews({super.key,required this.store});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(12),children:[ElevatedButton.icon(onPressed:(){showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('Breaking News'),content:const TextField(maxLines:4,decoration:InputDecoration(hintText:'Write news here')),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Publish'))]));},icon:const Icon(Icons.add),label:const Text('Add Breaking News')), ...store.news.map((n)=>Card(child:ListTile(title:Text(n.title),subtitle:Text(n.text))))]);}
class AdminAnalytics extends StatelessWidget{final AppStore store;const AdminAnalytics({super.key,required this.store});@override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Analytics / হিসাব',style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),const SizedBox(height:15),_row('Total Users','1,248'),_row('Online Now','86'),_row('New Jobs Today',store.jobs.length.toString()),_row('Active Jobs',store.jobs.length.toString()),_row('Applications',store.applications.length.toString()),_row('Jobs Expiring ≤ 3 Days',store.jobs.where((j)=>j.remainingDays<=3).length.toString()),const SizedBox(height:15),const Text('Job validity is calculated from each job deadline. Application age is calculated from the submitted date.',style:TextStyle(color:Colors.black54))]);Widget _row(String a,String b)=>Card(child:ListTile(title:Text(a),trailing:Text(b,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))));}

class AdminTechnical extends StatelessWidget{const AdminTechnical({super.key});@override Widget build(BuildContext c)=>Scaffold(body:ListView(padding:const EdgeInsets.all(16),children:['Packaging Calculator','Film Database','Printing Guide','Lamination Guide','Slitting Guide','Sealing Guide','Multilayer Pouch','Quality Control','Problems & Solutions','Safety'].map((x)=>Card(child:ListTile(title:Text(x),trailing:const Icon(Icons.edit_outlined),subtitle:const Text('Admin can update Bangla and English content')))).toList()));}}
