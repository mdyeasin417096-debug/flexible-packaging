import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FirebaseService {
  FirebaseService._();
  static final instance = FirebaseService._();
  final auth = FirebaseAuth.instance;
  final db = FirebaseFirestore.instance;
  final storage = FirebaseStorage.instance;
  final messaging = FirebaseMessaging.instance;

  User? get user => auth.currentUser;

  Future<UserCredential> register(String email, String password) =>
      auth.createUserWithEmailAndPassword(email: email, password: password);

  Future<UserCredential> login(String email, String password) =>
      auth.signInWithEmailAndPassword(email: email, password: password);

  Future<void> sendPasswordReset(String email) => auth.sendPasswordResetEmail(email: email);

  Future<void> sendEmailVerification() async {
    final u = auth.currentUser;
    if (u != null && !u.emailVerified) await u.sendEmailVerification();
  }

  Future<void> logout() => auth.signOut();

  Future<void> saveUserProfile(String uid, Map<String, dynamic> data) =>
      db.collection('users').doc(uid).set({...data, 'updatedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));

  Future<DocumentSnapshot<Map<String, dynamic>>> getUserProfile(String uid) =>
      db.collection('users').doc(uid).get();

  Future<String> uploadFile({required String uid, required File file, required String folder}) async {
    final ref = storage.ref('$folder/$uid/${DateTime.now().millisecondsSinceEpoch}_${file.uri.pathSegments.last}');
    await ref.putFile(file);
    return ref.getDownloadURL();
  }

  Future<void> registerMessagingToken(String uid) async {
    final token = await messaging.getToken();
    if (token != null) {
      await db.collection('users').doc(uid).collection('devices').doc(token).set({
        'token': token,
        'platform': Platform.isAndroid ? 'android' : 'other',
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> jobsStream() =>
      db.collection('jobs').where('active', isEqualTo: true).orderBy('postedAt', descending: true).snapshots();

  Future<void> saveJob(String uid, String jobId) =>
      db.collection('users').doc(uid).collection('savedJobs').doc(jobId).set({'jobId': jobId, 'savedAt': FieldValue.serverTimestamp()});

  Future<void> unsaveJob(String uid, String jobId) =>
      db.collection('users').doc(uid).collection('savedJobs').doc(jobId).delete();

  Future<void> applyJob(String uid, String jobId, Map<String, dynamic> data) =>
      db.collection('applications').add({...data, 'uid': uid, 'jobId': jobId, 'status': 'Under Review', 'createdAt': FieldValue.serverTimestamp()});
}
